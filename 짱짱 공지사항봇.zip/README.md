# Currently not maintained!

# Announce-Discord-Bot

Simple announcement bot that mentions a role, and can only be used by a role. Can upload a picture as well.

## Instructions

1. Rename `example.env` to `.env` or setup environmental variables and set according to comments
2. `npm install`
3. `npm start`

## License

MIT
